import { NextResponse } from "next/server"

// URL of your local model server
const MODEL_SERVER_URL = process.env.MODEL_SERVER_URL || "http://localhost:8000"

export async function POST(req: Request) {
  try {
    const { messages, userLocation } = await req.json()

    // Get the last user message
    const lastUserMessage = messages.filter((m: any) => m.role === "user").pop()

    if (!lastUserMessage) {
      return NextResponse.json({
        response: "I'm sorry, I couldn't understand your message. Could you please try again?",
      })
    }

    // Create a context-aware prompt
    const contextPrefix =
      userLocation === "pakistan"
        ? "As a mental health assistant for Pakistani users, "
        : "As a mental health assistant, "

    // Get the last few messages for context (up to 3)
    const recentMessages = messages.slice(-3)
    const conversationHistory = recentMessages
      .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
      .join("\n")

    // Create the final prompt
    const prompt = `${contextPrefix}please provide a helpful response to this conversation:\n\n${conversationHistory}\n\nUser: ${lastUserMessage.content}\nAssistant:`

    try {
      // Call the local model server
      const modelResponse = await fetch(`${MODEL_SERVER_URL}/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt: prompt,
          max_length: 300,
          temperature: 0.7,
        }),
      })

      if (!modelResponse.ok) {
        throw new Error(`Model server request failed with status ${modelResponse.status}`)
      }

      const result = await modelResponse.json()
      return NextResponse.json({ response: result.generated_text })
    } catch (error) {
      console.error("Error calling local model server:", error)

      // Fall back to the rule-based system if the local server fails
      const fallbackResponse = getIntelligentResponse(lastUserMessage.content, userLocation, messages)
      return NextResponse.json({ response: fallbackResponse })
    }
  } catch (error) {
    console.error("Error in chat API route:", error)
    return NextResponse.json(
      { response: "I'm sorry, I encountered an error processing your request. Please try again later." },
      { status: 500 },
    )
  }
}

/**
 * Provides an intelligent response based on the user's message (fallback)
 */
function getIntelligentResponse(userPrompt: string, userLocation: string | null, messages: any[]): string {
  const prompt = userPrompt.toLowerCase()
  const isPakistani = userLocation === "pakistan"

  // Check for anxiety-related queries
  if (
    prompt.includes("anxious") ||
    prompt.includes("anxiety") ||
    prompt.includes("worried") ||
    prompt.includes("panic") ||
    prompt.includes("nervous")
  ) {
    return isPakistani
      ? "I understand anxiety can be challenging. In Pakistani culture, anxiety might sometimes be viewed as weakness, but it's a common human experience. Try deep breathing exercises - inhale for 4 counts, hold for 4, and exhale for 6. Regular prayer can also provide comfort. Consider speaking with a trusted family elder or a professional if your anxiety persists."
      : "Anxiety can be challenging to deal with. Some helpful strategies include deep breathing exercises (inhale for 4 counts, hold for 4, exhale for 6), mindfulness meditation, and regular physical activity. It's also important to identify and challenge negative thought patterns. Remember that anxiety is a common experience, and seeking professional help is a sign of strength."
  }

  // Add more fallback responses for different topics...

  // Default response
  return isPakistani
    ? "I understand this might be challenging. In Pakistani culture, seeking support from family and community can be valuable. Consider speaking with someone you trust, and remember that taking care of your mental health is important."
    : "I understand this might be challenging. Remember that it's okay to seek support when needed. Taking small steps toward self-care and reaching out to trusted individuals can make a difference in your mental well-being."
}
