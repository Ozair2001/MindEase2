"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Layout from "../components/layout"
import { Brain, User, Send, Loader, LogIn, UserPlus } from "lucide-react"
import Link from "next/link"

interface Message {
  role: "user" | "assistant"
  content: string
}

interface QuickReply {
  text: string
  action: () => void
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showAuthPrompt, setShowAuthPrompt] = useState(false)
  const [userLocation, setUserLocation] = useState<"pakistan" | "other" | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const quickReplies: QuickReply[] = [
    { text: "I'm feeling anxious", action: () => handleQuickReply("I'm feeling anxious") },
    { text: "How to manage stress?", action: () => handleQuickReply("How to manage stress?") },
    { text: "Tell me about depression", action: () => handleQuickReply("Tell me about depression") },
    { text: "Help me sleep better", action: () => handleQuickReply("Help me sleep better") },
  ]

  useEffect(() => {
    const savedLocation = localStorage.getItem("userLocation")
    if (savedLocation) {
      setUserLocation(savedLocation as "pakistan" | "other")
    }
  }, [])

  useEffect(() => {
    if (userLocation) {
      const greeting =
        userLocation === "pakistan"
          ? "Assalam-o-alaikum! How can I assist you today?"
          : "Hello! How can I assist you today?"
      setMessages([{ role: "assistant", content: greeting }])
    }
  }, [userLocation])

  const handleQuickReply = (text: string) => {
    setInput(text)
    handleSubmit(new Event("submit") as any)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    if (!isLoggedIn && !showAuthPrompt) {
      setShowAuthPrompt(true)
      return
    }

    const userMessage = { role: "user" as const, content: input }
    setMessages((prevMessages) => [...prevMessages, userMessage])
    setInput("")
    setIsTyping(true)
    setShowAuthPrompt(false)

    try {
      // Add a realistic typing delay based on message length
      const typingDelay = Math.min(1000 + input.length * 10, 3000)
      await new Promise((resolve) => setTimeout(resolve, typingDelay))

      // Call our API with all messages for context
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          userLocation,
        }),
      })

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`)
      }

      const data = await response.json()

      // Add the AI response to messages
      setMessages((prevMessages) => [...prevMessages, { role: "assistant", content: data.response }])
    } catch (error) {
      console.error("Error fetching AI response:", error)
      setMessages((prevMessages) => [
        ...prevMessages,
        {
          role: "assistant",
          content: "I'm sorry, I encountered an error. Please try again later.",
        },
      ])
    } finally {
      setIsTyping(false)
    }
  }

  const handleContinueAnonymously = () => {
    setShowAuthPrompt(false)
    handleSubmit(new Event("submit") as any)
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, isTyping])

  if (!userLocation) {
    return (
      <Layout>
        <div className="flex justify-center items-center h-[calc(100vh-140px)] bg-gradient-to-b from-background to-accent">
          <p className="text-xl text-gray-600">Please select your location on the home page first.</p>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="flex flex-col h-[calc(100vh-140px)] bg-gradient-to-b from-background to-accent">
        <div className="flex-grow overflow-y-auto p-4 space-y-4">
          {messages.map((m, index) => (
            <div key={index} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`flex items-end space-x-2 ${m.role === "user" ? "flex-row-reverse space-x-reverse" : "flex-row"}`}
              >
                <div
                  className={`rounded-full p-2 ${m.role === "user" ? "bg-primary text-white" : "bg-white text-primary"}`}
                >
                  {m.role === "user" ? <User className="h-6 w-6" /> : <Brain className="h-6 w-6" />}
                </div>
                <div
                  className={`rounded-lg p-3 max-w-md ${m.role === "user" ? "bg-primary text-white" : "bg-white text-gray-800"}`}
                >
                  {m.content}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-center space-x-2">
                <div className="rounded-full p-2 bg-white text-primary">
                  <Loader className="h-6 w-6 animate-spin" />
                </div>
                <div className="rounded-lg p-3 bg-white text-gray-800">Mind Ease is typing...</div>
              </div>
            </div>
          )}
          {showAuthPrompt && (
            <div className="flex justify-center">
              <div className="bg-white rounded-lg p-4 shadow-lg">
                <p className="text-gray-800 mb-4">
                  Please log in or sign up to continue the conversation, or choose to continue anonymously.
                </p>
                <div className="flex justify-center space-x-4">
                  <Link
                    href="/login"
                    className="flex items-center px-4 py-2 bg-primary text-white rounded hover:bg-primary/90 transition-colors"
                  >
                    <LogIn className="mr-2 h-4 w-4" /> Log In
                  </Link>
                  <Link
                    href="/signup"
                    className="flex items-center px-4 py-2 bg-primary text-white rounded hover:bg-primary/90 transition-colors"
                  >
                    <UserPlus className="mr-2 h-4 w-4" /> Sign Up
                  </Link>
                  <button
                    onClick={handleContinueAnonymously}
                    className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition-colors"
                  >
                    Continue Anonymously
                  </button>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className="p-4 bg-white/50 backdrop-blur-md border-t border-gray-200">
          <div className="flex flex-wrap justify-center mb-4 space-x-2">
            {quickReplies.map((reply, index) => (
              <button
                key={index}
                onClick={reply.action}
                className="bg-white text-primary px-4 py-2 rounded-full text-sm font-medium hover:bg-primary hover:text-white transition-colors mb-2"
              >
                {reply.text}
              </button>
            ))}
          </div>
          <form onSubmit={handleSubmit} className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message here..."
              className="flex-grow p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              disabled={isTyping}
            />
            <button
              type="submit"
              className="bg-primary text-white p-2 rounded-lg hover:bg-primary/90 transition-colors"
              disabled={isTyping || !input.trim()}
            >
              <Send className="h-6 w-6" />
            </button>
          </form>
        </div>
      </div>
    </Layout>
  )
}
