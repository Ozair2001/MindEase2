import Link from "next/link"
import { Brain } from "lucide-react"
import type React from "react"

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white/5 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto flex flex-wrap justify-between items-center py-4 px-6">
          <Link href="/" className="flex items-center space-x-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold gradient-text">Mind Ease</span>
          </Link>
          <nav className="flex flex-col items-end space-y-4 mt-4 md:mt-0">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-gray-700 hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/chat" className="text-gray-700 hover:text-primary transition-colors">
                Chat
              </Link>
              <Link
                href="/login"
                className="px-4 py-2 rounded-lg text-primary border border-primary hover:bg-primary hover:text-white transition-colors"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-purple-900 text-white hover:opacity-90 transition-colors"
              >
                Sign Up
              </Link>
            </div>
            <div className="flex items-center space-x-4 text-sm">
              <Link href="/learn-more" className="text-gray-500 hover:text-primary transition-colors">
                Learn More
              </Link>
              <Link href="/faqs" className="text-gray-500 hover:text-primary transition-colors">
                FAQs
              </Link>
              <Link href="/about-us" className="text-gray-500 hover:text-primary transition-colors">
                About Us
              </Link>
            </div>
          </nav>
        </div>
      </header>
      <main className="flex-grow">{children}</main>
      <footer className="bg-white/5 backdrop-blur-md border-t border-white/10">
        <div className="container mx-auto py-6 px-6 text-center text-gray-600">
          © 2024 Mind Ease. All rights reserved.
        </div>
      </footer>
    </div>
  )
}
